# Word2Vec-NLP
Word Analogy using NCE Loss and Cross Entropy #NLP
